import android.content.ContentValues;
public void 尾巴(Object data) {
    String e=emojilist[new Random().nextInt(emojilist.length)];
    data.values.put("content",e+data.content+e);
}