public class 每日简报 {
    boolean mrjb=true;
    ScheduledExecutorService scheduler=Executors.newScheduledThreadPool(1);
    scheduler.scheduleAtFixedRate(new Runnable() {
        public void run() {
            LocalDateTime now=LocalDateTime.now();
            if(!mrjb&&now.getHour()!=9&&now.getMinute()>3) {
                mrjb=true;
            }
            if(mrjb&&now.getHour()==9&&now.getMinute()<=3) {
                mrjb=false;
                for (String qun:getGroups()) {
                    if("1".equals(getString(qun,"每日简报",""))&&"1".equals(getString(qun,"开关",""))) {
                        String text="";
                        String result=get("https://api.vvhan.com/api/60s");
                        JSONObject json=new JSONObject(result);
                        Boolean success=json.getBoolean("success");
                        if(success) {
                            String time=json.getString("time");
                            JSONArray data=json.getJSONArray("data");
                            for(int i=0;i<data.length();i++) {
                                if(i<data.length()-1) {
                                    text+=(i+1)+"、"+data.getString(i)+"\n";
                                } else {
                                    text+=data.getString(i);
                                }
                            }
                            text=time+"\n"+text;
                            sendMsg(qun,text);
                        }
                    }
                }
            }
        }
    },timeUntilNext(3,3),1,TimeUnit.MINUTES);
} new 每日简报();
public void 简报(Object data) {
    String text=data.content;
    String qun=data.talker;
    String wxid=data.sendTalker;
    if(text.equals("简报测试")) {
        String text="";
        String result=get("https://api.vvhan.com/api/60s");
        JSONObject json=new JSONObject(result);
        Boolean success=json.getBoolean("success");
        if(success) {
            String time=json.getString("time");
            JSONArray data=json.getJSONArray("data");
            for(int i=0;i<data.length();i++) {
                if(i<data.length()-1) {
                    text+=(i+1)+"、"+data.getString(i)+"\n";
                } else {
                    text+=data.getString(i);
                }
            }
            text=time+"\n"+text;
            sendMsg(qun,text);
        }
    }
}