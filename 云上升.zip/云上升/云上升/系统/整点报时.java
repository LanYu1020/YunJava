public class 整点报时 {
    boolean zdbs=true;
    ScheduledExecutorService scheduler=Executors.newScheduledThreadPool(1);
    scheduler.scheduleAtFixedRate(new Runnable() {
        public void run() {
            SimpleDateFormat df=new SimpleDateFormat("yyyy年MM月dd日HH:mm:ss");
            Calendar calendar=Calendar.getInstance();
            LocalDateTime now=LocalDateTime.now();
            if(!zdbs&&now.getMinute()>3&&now.getHour()!=9) {
                zdbs=true;
            }
            if(zdbs&&now.getMinute()<=3&&now.getHour()!=9) {
                zdbs=false;
                String time=df.format(calendar.getTime());
                String baoshi=get("https://xiaoapi.cn/API/zs_zdbs.php?h="+now.getHour());
                String msg="";
                JSONObject json=new JSONObject(baoshi);
                Integer code=json.getInt("code");
                if(code==200) {
                    msg=json.getString("msg");
                }
                for (String qun:getGroups()) {
                    if("1".equals(getString(qun,"整点报时",""))&&"1".equals(getString(qun,"开关",""))) {
                        sendMsg(qun,"整点报时\n"+msg+"\n"+time);
                    }
                }
            }
        }
    },timeUntilNext(3,4),1,TimeUnit.SECONDS);
} new 整点报时();

public void 报时(Object data) {
    String text=data.content;
    String qun=data.talker;
    String wxid=data.sendTalker;
    if(text.equals("报时测试")) {
        SimpleDateFormat df=new SimpleDateFormat("yyyy年MM月dd日HH:mm:ss");
        Calendar calendar=Calendar.getInstance();
        LocalDateTime now=LocalDateTime.now();
        String time=df.format(calendar.getTime());
        String baoshi=get("https://xiaoapi.cn/API/zs_zdbs.php?h="+now.getHour());
        String msg="";
        JSONObject json=new JSONObject(baoshi);
        Integer code=json.getInt("code");
        if(code==200) {
            msg=json.getString("msg");
        }
        sendMsg(qun,"报时测试\n"+msg+"\n"+time);
    }
}