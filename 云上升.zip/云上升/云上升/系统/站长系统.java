public void 站长(Object data) {
String text=data.content;
String qun=data.talker;
String wxid=data.sendTalker;
    if(text.startsWith("访问")) {
        Thread thread=new Thread(new Runnable() {
            public void run() {
                text=text.substring(2);
                String urlPattern="(\\/?|\\b)((https?|ftp|file):\\/\\/|www\\.|[-a-zA-Z0-9+&@#/%?=~_|!:,.;])[-a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-a-zA-Z0-9+&@#/%=~_|\\p{IsHan}]*";
                Pattern pattern=Pattern.compile(urlPattern);
                Matcher matcher=pattern.matcher(text);
                if(matcher.find()) {
                    String url=matcher.group();
                    try {
                        StringBuffer buffer=new StringBuffer();
                        InputStreamReader isr=null;
                        HttpURLConnection uc=(HttpURLConnection) new URL(url).openConnection();
                        uc.setConnectTimeout(240000);
                        uc.setReadTimeout(240000);
                        String c="";
                        int responseCode=uc.getResponseCode();
                        if(responseCode==HttpURLConnection.HTTP_OK) {
                            isr=new InputStreamReader(uc.getInputStream(),"utf-8");
                            BufferedReader reader=new BufferedReader(isr);
                            String line;
                            while ((line=reader.readLine()) != null) {
                                buffer.append(line+"\n");
                            }
                            isr.close();
                            String contentType=uc.getContentType();
                            if(contentType!=null) {
                                if(contentType.startsWith("video/")) {
                                    sendMsg(qun,"视频链接："+url);
                                } else if(contentType.startsWith("image/")) {
                                    sendPic(qun,url);
                                } else if(contentType.startsWith("audio/")) {
                                    sendMsg(qun,"音频链接："+url);
                                } else {
                                    c=buffer.toString();
                                    if(c.length()>3000) {
                                        c=c.substring(0,3000)+"\n\n……（超过3000字，内容已截断）";
                                    }
                                    sendMsg(qun,c);
                                }
                            }
                        } else if(responseCode==HttpURLConnection.HTTP_MOVED_PERM||responseCode==HttpURLConnection.HTTP_MOVED_TEMP) {
                            String redirectUrl=uc.getHeaderField("Location");
                            if(redirectUrl!=null) {
                                c=redirectUrl;
                                if(c.length()>500) {
                                    c=c.substring(0,500)+"\n\n……（超过500字，内容已截断）";
                                }
                                sendMsg(qun,c);
                            } else {
                                c="失败，无法获取重定向链接";
                                sendMsg(qun,c);
                            }
                        } else {
                            c="失败，HTTP状态码: "+responseCode;
                            sendMsg(qun,c);
                        }
                    } catch(Exception e) {
                        String errorMessage="失败，原因: "+e.getMessage();
                        sendMsg(qun,errorMessage);
                    }
                }
            }
        });
        thread.start();
    }
}